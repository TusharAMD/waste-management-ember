<div id="tb-blog-metabox" class='tb_metabox'>
	<?php
	$this->uploadimage('post_gallery',
			'If you would like to add more images for a slider, you can add them here.',
			esc_html__('Please add more images for a slider','hala')
	);
	?>
</div>