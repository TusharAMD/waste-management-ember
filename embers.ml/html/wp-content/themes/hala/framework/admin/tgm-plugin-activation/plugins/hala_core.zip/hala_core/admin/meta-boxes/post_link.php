<div id="tb-blog-metabox" class='tb_metabox'>
	<?php
	$this->text('post_link',
			'Link URL',
			'',
			esc_html__('Please input the URL for your link. http://www.youwebsite.com','hala')
	);
	?>
</div>